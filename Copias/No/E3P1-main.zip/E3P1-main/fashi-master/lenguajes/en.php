<?php

$lang = array(

    "titulo" => "K-Beauty Your korean cosmetics shop",
    "login" => "Login",
    "categories" => "Categories",
    "categories_description" => "Search",
    "total" => "Total:",
    "cart_view" => "VIEW CART",
    "check_out" => "CHECK OUT",
    "eslogan" => "SHOP NOW",
    "Inicio" => "Home",
    "Precios" => "Pricing",
    "Contacto" => "Contact",
    "Descripcion" => "This is the description of my English Website",
    "Titular" => "My Website in English",
    "en" => '<img src="img/flag-1.jpg"></img>',
    "es" => '<img src="img/flag-4.png" width="25px"></img>',
    "eus" => '<img src="img/flag-3.png"></img>',
);