<?php

$lang = array(

    "titulo" => "K-Beauty Tu tienda online de kosmetika koreana",
    "login" => "Iniciar Sesion",
    "categories" => "Categorias",
    "categories_description" => "Buscar",
    "total" => "Total:",
    "cart_view" => "VER CESTA",
    "check_out" => "PROCEDER AL PAGO",
    "eslogan" => "FINALIZAR COMPRA",
    "Inicio" => "Inicio",
    "Precios" => "Precios",
    "Contacto" => "Contacto",
    "Descripcion" => "Esta es la descripción de mi Sitio Web en Español",
    "Titular" => "Mi Página Web en Español",
    "en" => '<img src="img/flag-1.jpg"></img>',
    "es" => '<img src="img/flag-4.png" width="25px"></img>',
    "eus" => '<img src="img/flag-3.png"></img>',
);