<?php

$lang = array(

    "titulo" => "K-Beauty Zure kosmetika koreak denda",
    "login" => "Saioa hasi",
    "categories" => "Kategoriak",
    "categories_description" => "Bilatu",
    "total" => "Totala:",
    "cart_view" => "SASKIA IKUSI",
    "check_out" => "EROSKETA AMAITU",
    "Inicio" => "iniziazione",
    "Precios" => "Prezzi",
    "Contacto" => "Contatto",
    "Descripcion" => "Questa è la descrizione del mio sito Web Italiano",
    "Titular" => "Il mio sito Web in Italiano",
    "en" => '<img src="img/flag-1.jpg"></img>',
    "es" => '<img src="img/flag-4.png" width="25px"></img>',
    "eus" => '<img src="img/flag-3.png"></img>',

);